import React from "react";
import "./CCstyles/Footer.css";
function Footer() {
  return (
    //   <div className="footer">
    //     <h3 className="footer__title">footer</h3>
    //   </div>
    <div>footer</div>
  );
}

export default Footer;
